package uk.ac.kent.jh927.week1_3_application;
import android.icu.util.RangeValueIterator;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.jar.Attributes;
/**
 * Created by jh927 on 05/10/2017.
 */
public class AppMain {
    public static ArrayList<Student> StudentList = new ArrayList<Student>(); //creation of the Student Array list
    public static ArrayList<Teacher> TeacherList = new ArrayList<Teacher>();//Creation of the Teacher Array list
    public static ArrayList<CourseModule> ModuleList = new ArrayList<CourseModule>();// Creation of the Course Array list

    public static void main(String[] args) {
        int option = 0; //set option selection to 0'
        while (option != 7) {
            Scanner in = new Scanner(System.in);
            System.out.println("Choose an option");
            System.out.println("[1] Create student");
            System.out.println("[2] List student");
            System.out.println("[3] Create Teacher");
            System.out.println("[4] List Teacher");
            System.out.println("[5] Create Module");
            System.out.println("[6] List Module");
            System.out.println("[7] Exit");
            System.out.print("Option? ");
            option = in.nextInt();
            switch (option) {
                case 1: //if selection (Option) == 0 Start creation of student
                    Student nstudent = new Student();
                    StudentList.add(nstudent);
                    break;
                case 2: //if selection == 2 Start listing student in StudentList
                    Iterator itS = StudentList.iterator();
                    while (itS.hasNext()) {
                        Student element = (Student) itS.next();
                        System.out.println("Student Name: " +element.getName());
                        System.out.println("Student Grade: " +element.getGrade());
                    }
                    break;
                case 3://if selection == 3 start creation of teacher
                    Teacher nteacher = new Teacher();
                    TeacherList.add(nteacher);
                    break;
                case 4://if selection == 4 start listing teacher in teacherlist
                    Iterator itT = TeacherList.iterator();
                    while (itT.hasNext()) {
                        Teacher element = (Teacher) itT.next();
                        System.out.println("Teacher Name: " +element.getName());
                    }
                    break;
                case 5:// if selection == 5 start creating modules.
                    CourseModule ncoruse = new CourseModule();
                    ModuleList.add(ncoruse);
                    break;
                case 6:// if selection ==6 start listing modules their teachers and their students
                    Iterator itM = ModuleList.iterator();
                    while (itM.hasNext()) {
                        Course element = (Course) itM.next();
                        System.out.println("Course Code: " +element.getcoursecode());
                        System.out.println("Course Teacher: " +element.getTeachername());
                        System.out.println("Students enrolled in course: ");
                        element.displayStudentOncourse();
                    }
                    break;
                case 7: //if selection == 7 give notification of ending application
                    System.out.println("Ending Application...");
                    break;
                default: //default setting for error handling
                    System.out.println("ERROR: Setting number not found!");
                    break;
            }
        }
    }

    public static ArrayList<Teacher> gettList() { //pass Teacher list to another class
        return TeacherList;
    }

    public static ArrayList<Student> getsList() { // pass student list to another class
        return StudentList;
    }
    public static boolean isAlpha(String name) {
        return name.matches("[a-zA-Z]+");
    }
}