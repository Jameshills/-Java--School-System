package uk.ac.kent.jh927.week1_3_application;
import org.w3c.dom.NameList;

import java.util.Scanner;
/**
 * Created by jh927 on 05/10/2017.
 */
public class Person {
    private  String Name;
    public Person() {
        setName();
    }
        public  String getName(){
            return Name;
        }
    private void setName() {
        int x = 0;
        while (x == 0) {
            Scanner user_input = new Scanner(System.in);
            System.out.print("Enter your full name: ");
            String N = user_input.next();
            Name = N;
            if (Name == null) {
                System.out.println("ERROR: No Character's Entered");
            } else if (AppMain.isAlpha(Name) == false) {
                System.out.println("ERROR: Non Alphabetic Character Entered");
            } else {
                x = 1;
            }
        }
    }

}