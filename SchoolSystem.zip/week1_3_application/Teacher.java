package uk.ac.kent.jh927.week1_3_application;

/**
 * Created by hills on 08/10/2017.
 */

public class Teacher extends Person {
    public Teacher() {
        super();
    }
            }