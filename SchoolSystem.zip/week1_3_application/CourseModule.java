package uk.ac.kent.jh927.week1_3_application;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
/**
 * Created by hills on 08/10/2017.
 */
public class CourseModule implements Course {
    public ArrayList<Teacher> tlist = AppMain.gettList();
    public ArrayList<Student> slist = AppMain.getsList();
    public ArrayList<String> tname = new ArrayList<String>();
    public ArrayList<String> sname = new ArrayList<String>();
    public ArrayList<Student> enrolledStudent = new ArrayList<Student>();
    Teacher lecturer;
    Student learner;
    String Teachername;
    String coursecode;

    public CourseModule() {
        Iterator itT = tlist.iterator();
        while (itT.hasNext()) {
            Teacher element = (Teacher) itT.next();
            String name = element.getName();
            tname.add(name);
        }
        Scanner user_input = new Scanner(System.in);
        System.out.println("Enter Module Code: ");
        coursecode = user_input.next();
        int x = 0;
        while (x == 0) {
            System.out.println("Enter Teacher Name: ");
            String uin = user_input.next();
            if (tname.contains(uin)) {
                x = 1;
                System.out.println("Adding Teacher to Module...");
                int pos = tlist.indexOf(uin) + 1;
                lecturer = tlist.get(pos);
                assignTeacher(lecturer);
            } else {
                System.out.println("ERROR: Teacher Not Found.");
            }
        }
        addStudent();

    }

    public void assignTeacher(Teacher teacher) {
        Teachername = teacher.getName();
    }

    public void enrolStudent(Student student) {
        enrolledStudent.add(student);
    }

    public void displayStudentOncourse() {
        Iterator Stuit = slist.iterator();
        while (Stuit.hasNext()) {
            Student element = (Student) Stuit.next();
            String name = element.getName();
            System.out.println(name);
        }
    }

    public String getcoursecode() {
        return coursecode;
    }

    public String getTeachername() {
        return Teachername;
    }

    public void addStudent() {
        int c=0;
        boolean again = true;
        Iterator itS = slist.iterator();
        while (again == true) {
            while (itS.hasNext()) {
                Student element = (Student) itS.next();
                String name = element.getName();
                sname.add(name);
            }
            Scanner user_input = new Scanner(System.in);
            int x = 0;
            while (x == 0) {
                System.out.println("Enter Student Name to Enroll: ");
                String suin = user_input.next();
                if (sname.contains(suin)) {
                    x = 1;
                    System.out.println("Adding Student to Module...");
                    int pos = slist.indexOf(suin) + 1;
                    learner = slist.get(pos);
                    enrolStudent(learner);
                } else {
                    System.out.println("ERROR: Student Not Found.");
                }
                c=0;
                while (c == 0) {
                    System.out.println("Would you like to add another Student? Y/N ");
                    String awnser = user_input.next();
                    String s = awnser.toUpperCase();
                    char letter = s.charAt(0);
                    if (awnser == null) {
                        System.out.println("ERROR: No Character's Entered");
                    } else if (AppMain.isAlpha(awnser) == false) {
                        System.out.println("ERROR: Non Alphabetic Character Entered");
                    } else if (letter == 'Y') {
                        again = true;
                        c=1;
                    } else if (letter == 'N') {
                        again = false;
                        c=1;
                    } else {
                        System.out.println("ERROR: Input not recognised try again");
                        c=0;
                    }
                }
            }
        }
    }
}