package uk.ac.kent.jh927.week1_3_application;
import java.util.ArrayList;
/**
 * Created by hills on 08/10/2017.
 */
public interface Course{
    public void assignTeacher(Teacher teacher);
    public void enrolStudent(Student student);
    public void displayStudentOncourse();
    public String getcoursecode();
    public String getTeachername();
    public void addStudent();
    }
