package uk.ac.kent.jh927.week1_3_application;
import java.util.Scanner;
/**
 * Created by jh927 on 05/10/2017.
 */
public class Student extends Person{
    char grade;
    public Student() {
        super();
        setGrade();
    }
    public char getGrade() {
        return grade;
    }
    public void setGrade() {
        Scanner user_input = new Scanner(System.in);
        String tempg = "x";
        int c = 0;
        while ( c == 0) {
            System.out.print("Enter Student Grade: ");
            tempg = user_input.next();
            String s = tempg.toUpperCase();
            char letter = s.charAt(0);
            this.grade = letter;
            if(tempg == null) {
                System.out.println("ERROR: Grade Not Valid Character(A,B,C,D,F)");
            }
           else if(tempg.length()>1){
                System.out.println("Too many Characters Entered.");
            } else if (letter == 'A' || letter == 'B' || letter == 'C' || letter =='D' || letter == 'F'){
                c=1;
            }else {
                System.out.println("ERROR: Grade Not Valid Character(A,B,C,D,F)");
            }
        }
    }
}


